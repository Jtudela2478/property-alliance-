export const metadata = { title: "Property Alliance PRO" };
export default function RootLayout({ children }: { children: React.ReactNode }){
  return (
    <html lang="en">
      <body style={{background:'#0b1220',color:'#e5e7eb',fontFamily:'ui-sans-serif,system-ui'}}>
        <div style={{borderBottom:'1px solid #1f2937',padding:'12px 16px',display:'flex',justifyContent:'space-between',alignItems:'center',background:'#0f172a'}}>
          <div style={{display:'flex',alignItems:'center',gap:10}}>
            <img src="/logo.svg" alt="logo" style={{width:28,height:28}}/>
            <div style={{fontWeight:900,letterSpacing:0.5}}>Property Alliance PRO</div>
          </div>
          <div style={{display:'flex',gap:12,fontSize:14}}>
            <a href="/" style={{color:'#93c5fd'}}>Home</a>
            <a href="/single" style={{color:'#93c5fd'}}>Single</a>
            <a href="/bulk" style={{color:'#93c5fd'}}>Bulk</a>
          </div>
        </div>
          <div style={{display:'flex',gap:12,fontSize:14}}>
            <a href="/" style={{color:'#93c5fd'}}>Home</a>
            <a href="/single" style={{color:'#93c5fd'}}>Single</a>
            <a href="/bulk" style={{color:'#93c5fd'}}>Bulk</a>
          </div>
        </div>
        {children}
      </body>
    </html>
  );
}
