"use client";
import { useState } from "react";
import { rowsToCsv } from "../shared";

export default function Bulk(){
  const [csv,setCsv]=useState<File|null>(null);
  const [rows,setRows]=useState<any[]|null>(null);
  const [loading,setLoading]=useState(false);
  const [emails,setEmails]=useState<string>("");
  const [targets,setTargets]=useState({ roiTarget:12, cocTarget:10, minDSCR:1.25, vacancy:5, mgmt:8, maint:5, capex:5, rate:7.25 });
  const [aiTopN,setAiTopN]=useState(25);

  async function analyze(){
    if(!csv) return;
    setLoading(true);
    try{
      const fd = new FormData();
      fd.append("file", csv);
      fd.append("targets", JSON.stringify(targets));
      fd.append("aiTopN", String(aiTopN));
      const res = await fetch("/api/bulk", { method:"POST", body: fd });
      if(!res.ok) throw new Error(await res.text());
      const j = await res.json();
      setRows(j.ranked);
      setEmails(j.emails);
    }catch(e:any){ alert(e?.message||"Analyze failed"); }
    finally{ setLoading(false); }
  }

  function download(name: string, text: string){
    const blob = new Blob([text], {type:"text/plain"});
    const url = URL.createObjectURL(blob);
    const a=document.createElement("a"); a.href=url; a.download=name; a.click(); URL.revokeObjectURL(url);
  }

  return (
    <main style={{padding:24,display:"grid",gap:16}}>
      <h1 style={{fontSize:28,fontWeight:800}}>Bulk Upload</h1>
      <div style={{border:"1px solid #334155",borderRadius:16,padding:12,background:"#0f172a",display:'grid',gap:8}}>
        <div>CSV columns supported: <code>address,url,price,rent,taxesAnnual,insuranceAnnual,vacancyPct,mgmtPct,maintenancePct,capexPct,hoaMonthly,ownerUtilitiesMonthly,closingPct,repairs,downPct,ratePct,termYears,beds,baths,sqft,yearBuilt,zip</code></div>
        <div style={{display:"grid",gridTemplateColumns:"1fr auto",gap:8}}>
          <input type="file" accept=".csv" onChange={e=> setCsv(e.target.files?.[0]||null)} />
          <button onClick={analyze} disabled={!csv||loading} style={{padding:"10px 14px",borderRadius:10,background:"#4f46e5",color:"#fff",fontWeight:700}}>{loading?"Analyzing…":"Analyze List"}</button>
        </div>
        <div style={{display:"grid",gridTemplateColumns:"repeat(6,minmax(0,1fr))",gap:8}}>
          <label>ROI % <input type="number" value={targets.roiTarget} onChange={e=>setTargets(s=>({...s, roiTarget:Number(e.target.value)}))} style={{padding:8,borderRadius:10,border:'1px solid #334155',background:'#0b1220',color:'#e5e7eb'}}/></label>
          <label>CoC % <input type="number" value={targets.cocTarget} onChange={e=>setTargets(s=>({...s, cocTarget:Number(e.target.value)}))} style={{padding:8,borderRadius:10,border:'1px solid #334155',background:'#0b1220',color:'#e5e7eb'}}/></label>
          <label>Min DSCR <input type="number" step="0.05" value={targets.minDSCR} onChange={e=>setTargets(s=>({...s, minDSCR:Number(e.target.value)}))} style={{padding:8,borderRadius:10,border:'1px solid #334155',background:'#0b1220',color:'#e5e7eb'}}/></label>
          <label>Vac % <input type="number" step="0.5" value={targets.vacancy} onChange={e=>setTargets(s=>({...s, vacancy:Number(e.target.value)}))} style={{padding:8,borderRadius:10,border:'1px solid #334155',background:'#0b1220',color:'#e5e7eb'}}/></label>
          <label>Mgmt % <input type="number" step="0.5" value={targets.mgmt} onChange={e=>setTargets(s=>({...s, mgmt:Number(e.target.value)}))} style={{padding:8,borderRadius:10,border:'1px solid #334155',background:'#0b1220',color:'#e5e7eb'}}/></label>
          <label>Rate % <input type="number" step="0.05" value={targets.rate} onChange={e=>setTargets(s=>({...s, rate:Number(e.target.value)}))} style={{padding:8,borderRadius:10,border:'1px solid #334155',background:'#0b1220',color:'#e5e7eb'}}/></label>
        </div>
        <div style={{display:"grid",gridTemplateColumns:"repeat(3,minmax(0,1fr))",gap:8}}>
          <label>AI Boost Top N <input type="number" value={aiTopN} onChange={e=>setAiTopN(Number(e.target.value))} style={{padding:8,borderRadius:10,border:'1px solid #334155',background:'#0b1220',color:'#e5e7eb'}}/></label>
          <a href="/sample-properties.csv" style={{alignSelf:'center',color:'#93c5fd'}}>Download sample CSV</a>
        </div>
      </div>

      {rows && (
        <div style={{display:"grid",gap:12}}>
          <div style={{display:"grid",gridTemplateColumns:"repeat(3,minmax(0,1fr))",gap:8}}>
            <button onClick={()=>download("property-alliance-ranked.csv", rowsToCsv(rows))} style={{padding:"10px 14px",borderRadius:10,border:"1px solid #334155"}}>Export Ranked CSV</button>
            <button onClick={()=>download("property-alliance-ranked.json", JSON.stringify(rows,null,2))} style={{padding:"10px 14px",borderRadius:10,border:"1px solid #334155"}}>Export Ranked JSON</button>
            <button onClick={()=>download("agent-emails.txt", emails)} style={{padding:"10px 14px",borderRadius:10,border:"1px solid #334155"}}>Export Agent Emails (.txt)</button>
          </div>
          <div style={{fontSize:12,color:"#94a3b8"}}>Top 100 shown below. Full export includes all rows.</div>
          <div style={{display:"grid",gap:8}}>
            {rows.slice(0,100).map((r:any,i:number)=>(
              <div key={i} style={{border:"1px solid #334155",borderRadius:16,padding:12,display:"grid",gap:8}}>
                <div style={{display:"grid",gridTemplateColumns:"120px 1fr",gap:12}}>
                  <div style={{display:"grid",gap:6}}>
                    {(r.images||[]).slice(0,1).map((src:string,idx:number)=>(<img key={idx} src={src} style={{width:"120px",height:"90px",objectFit:"cover",borderRadius:10}}/>))}
                  </div>
                  <div style={{display:"grid",gridTemplateColumns:"1fr auto",gap:8}}>
                    <div>
                      <div style={{fontWeight:800}}>{i+1}. {r.address}</div>
                      <div style={{fontSize:13,color:"#94a3b8"}}>{r.description || ""}</div>
                      <div style={{display:"grid",gridTemplateColumns:"repeat(6,minmax(0,1fr))",gap:8,marginTop:8,fontSize:13}}>
                        <div><b>Price</b><div>${Math.round(r.price||0).toLocaleString()}</div></div>
                        <div><b>Rent</b><div>${Math.round(r.rent||0).toLocaleString()}</div></div>
                        <div><b>CF/mo</b><div>${Math.round(r.cfM||0).toLocaleString()}</div></div>
                        <div><b>CoC</b><div>{(r.coc||0).toFixed(2)}%</div></div>
                        <div><b>ROI</b><div>{(r.cap||0).toFixed(2)}%</div></div>
                        <div><b>DSCR</b><div>{(r.dscr||0).toFixed(2)}</div></div>
                      </div>
                      <div style={{marginTop:8,fontSize:13,display:"grid",gridTemplateColumns:"repeat(3,minmax(0,1fr))",gap:8}}>
                        <div><b>Sec 8 Net</b><div>${Math.round(r.s8Net||0).toLocaleString()} (UA ${Math.round(r.s8UA||0)})</div></div>
                        <div><b>PS</b><div>${Math.round(r.s8PSLow||0).toLocaleString()}–${Math.round(r.s8PSHigh||0).toLocaleString()} <span style={{fontSize:11,color:"#60a5fa"}}>({r.s8Source})</span></div></div>
                        <div><b>Recommended</b><div>{r.rec?.structure || "—"} @ ${Math.round(r.rec?.price||0).toLocaleString()}</div></div>
                      </div>
                      {r.ai && (
                        <div style={{marginTop:8,borderTop:'1px dashed #334155',paddingTop:8,display:'grid',gap:6}}>
                          <div style={{fontWeight:700}}>AI Notes</div>
                          <div><b>Rent Band:</b> ${Math.round(r.ai.rentCheck.low).toLocaleString()}–${Math.round(r.ai.rentCheck.high).toLocaleString()} ({r.ai.rentCheck.confidence})</div>
                          <div><b>Condition:</b> {r.ai.condition.label} — { (r.ai.condition.scope||[]).slice(0,3).join("; ") }</div>
                          <div><b>Risks:</b> { (r.ai.risks||[]).slice(0,3).join("; ") }</div>
                        </div>
                      )}
                    </div>
                    <div style={{textAlign:"right",fontSize:13}}>
                      <div><b>Agent</b></div>
                      <div>{r.agent?.name || "—"}</div>
                      <div>{r.agent?.phone || "—"}</div>
                      <div>{r.agent?.email || "—"}</div>
                      <div>{r.agent?.office || "—"}</div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </main>
  );
}
