export default function Page(){
  return (
    <main style={{padding:24,display:'grid',gap:16}}>
      <h1 style={{fontSize:28,fontWeight:800}}>Property Alliance PRO</h1>
      <p style={{color:'#94a3b8'}}>Analyze single addresses or bulk CSVs, auto-rank best deals, Section 8 (HUD) check, and AI Boost for rent bands, risks, and email drafts.</p>
      <div style={{display:'grid',gridTemplateColumns:'repeat(2,minmax(0,1fr))',gap:12}}>
        <a href="/single" style={{border:'1px solid #334155',borderRadius:16,padding:16,display:'block',textDecoration:'none',color:'#e5e7eb'}}>
          <div style={{fontWeight:800,marginBottom:6}}>🔍 Single Address</div>
          <div style={{fontSize:14,color:'#94a3b8'}}>Paste an address and optional listing URL.</div>
        </a>
        <a href="/bulk" style={{border:'1px solid #334155',borderRadius:16,padding:16,display:'block',textDecoration:'none',color:'#e5e7eb'}}>
          <div style={{fontWeight:800,marginBottom:6}}>📦 Bulk Upload</div>
          <div style={{fontSize:14,color:'#94a3b8'}}>Upload CSV → auto-ranked hot list + agent email drafts.</div>
        </a>
      </div>
    </main>
  );
}
