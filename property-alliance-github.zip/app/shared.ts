export type Agent = { name?: string; phone?: string; email?: string; office?: string };

export function asNumber(x: any, d: number){
  const n = Number(String(x ?? "").replace(/[^0-9.\-]/g,''));
  return isFinite(n) ? n : d;
}

export function analyze(i:any){
  const taxes=i.taxesAnnual/12, ins=i.insuranceAnnual/12;
  const v=i.rent*(i.vacancyPct/100), m=i.rent*(i.mgmtPct/100), maint=i.rent*(i.maintenancePct/100), cap=i.rent*(i.capexPct/100);
  const ops = taxes+ins+v+m+maint+cap;
  const down=i.price*(i.downPct/100), loan=Math.max(0,i.price-down);
  const pi= loan>0? ((i.ratePct/100/12)*loan)/(1-Math.pow(1+i.ratePct/100/12,-i.termYears*12)) : 0;
  const noiM=i.rent-ops, cfM=noiM-pi; const annualNOI=noiM*12, annualDebt=pi*12;
  const totalIn=down+(i.price*(i.closingPct/100))+(i.repairs||0);
  const coc = totalIn>0 ? (cfM*12)/totalIn*100 : 0;
  const capRate = i.price>0 ? (annualNOI/i.price)*100 : 0;
  const dscr = annualDebt>0 ? (annualNOI/annualDebt) : 999;
  return { cfM, cap: capRate, coc, dscr, totalIn, annualNOI, pi };
}

export function scoreRow(r:any, targets:any){
  const cocTarget = targets.cocTarget ?? 10;
  const roiTarget = targets.roiTarget ?? 12;
  const minDSCR = targets.minDSCR ?? 1.25;
  let s=0;
  const cocBandPenalty = Math.max(0, Math.abs(r.coc - cocTarget) - 1.5);
  s += 30 - Math.min(30, cocBandPenalty * 8);
  const roiPenalty = Math.max(0, Math.abs(r.cap - roiTarget) - 2.5);
  s += 20 - Math.min(20, roiPenalty * 4);
  s += Math.min(15, Math.max(0, r.cfM/50));
  if (r.cfM <= 0) s -= 20;
  if (r.dscr >= minDSCR) s += 15; else s -= 25;
  if (r.dscr >= 1.35) s += 5;
  return s;
}

export function s8UAForBeds(beds:number|undefined){
  const b=beds||3;
  return b>=4?220 : b===3?180 : b===2?150 : 120;
}
export function s8Fallback(marketRent:number, beds:number|undefined){
  const ua = s8UAForBeds(beds);
  const psLow = Math.round(marketRent*0.95);
  const psHigh = Math.round(marketRent*1.05);
  const net = Math.max(0, Math.round(marketRent*0.97) - ua);
  return {ua, psLow, psHigh, net, source:"Heuristic"};
}

export function pickRecommended(base:any, targets:any){
  const conv = analyze(base);
  const roi = (targets.roiTarget??12)/100;
  let cashPrice = Math.max(50000, Math.round((conv.annualNOI/roi)/500)*500);
  const cash = analyze({ ...base, price: cashPrice, downPct: 100, ratePct: 0 });
  const offerCash = { structure:"Cash", price: cashPrice, cfM: cash.cfM, coc: cash.coc, dscr: 999, notes:`Target ~${targets.roiTarget??12}% ROI` };

  let best:any=null; let sfPrice=base.price*0.97, sfRate=Math.max(3.5, base.ratePct-3), sfDown=Math.min(10, base.downPct);
  for(let i=0;i<40;i++){
    const test = analyze({ ...base, price: sfPrice, ratePct: sfRate, downPct: sfDown, termYears: 30 });
    const coc = test.coc, ok = test.dscr >= (targets.minDSCR??1.25);
    const score = Math.abs(coc - (targets.cocTarget??10)) + (ok ? 0 : 100);
    if(!best || score < best.score) best = { score, price: sfPrice, rate: sfRate, down: sfDown, stats: test };
    if(!ok || coc < (targets.cocTarget??10)){ sfPrice*=0.985; sfRate=Math.max(2.5, sfRate-0.1); } else { sfPrice*=1.003; }
  }
  const offerSF = { structure:"Seller Finance", price: Math.round(best.price), cfM: best.stats.cfM, coc: best.stats.coc, dscr: best.stats.dscr, notes: `${best.down}% down @ ${best.rate.toFixed(2)}%` };

  const s8stats = analyze({ ...base, price: base.price*0.98, rent: Math.max(0, Math.round(base.rent*0.97)-s8UAForBeds(base.beds)), vacancyPct: Math.max(0, (base.vacancyPct||5)-2) });
  const offerS8 = { structure:"Section 8 Conv.", price: Math.round(base.price*0.98), cfM: s8stats.cfM, coc: s8stats.coc, dscr: s8stats.dscr, notes:`Est. UA ${s8UAForBeds(base.beds)}` };

  const choices = [offerSF, offerCash, offerS8].sort((a,b)=> (b.coc - a.coc) || (b.dscr - a.dscr));
  const rec = choices[0];
  return { rec, offers: choices };
}

export function currency(n:number){ return n.toLocaleString(undefined,{style:'currency',currency:'USD',maximumFractionDigits:0}); }

export function rowsToCsv(rows: any[]){
  const cols = ["address","price","rent","cfM","coc","cap","dscr","totalIn","s8Net","s8UA","s8PSLow","s8PSHigh","s8Source","rec.structure","rec.price","rec.cfM","rec.coc","rec.dscr","agent.name","agent.phone","agent.email","agent.office"];
  const safe = (v:any)=>{
    const s = typeof v==='object' ? '' : String(v??'');
    return /[\",\n]/.test(s) ? '"'+s.replace(/"/g,'""')+'"' : s;
  };
  const lines = [cols.join(",")];
  for(const r of rows){
    lines.push(cols.map(c=>{
      if(c.startsWith("agent.")){ const k=c.split(".")[1]; return safe(r.agent?.[k]??""); }
      if(c.startsWith("rec.")){ const k=c.split(".")[1]; return safe(r.rec?.[k]??""); }
      return safe(r[c]);
    }).join(","));
  }
  return lines.join("\n");
}
