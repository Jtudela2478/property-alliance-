import { NextRequest, NextResponse } from "next/server";
import { analyze, asNumber, pickRecommended, scoreRow, s8Fallback } from "../../shared";
import { enrichFromUrl, extractZip } from "../_lib";

async function aiSuggest(payload:any){
  try{
    const base = process.env.NEXT_PUBLIC_BASE_URL || "";
    const res = await fetch(`${base}/api/ai/suggest`, { method:"POST", headers:{ "Content-Type":"application/json" }, body: JSON.stringify(payload) });
    if(!res.ok) return null;
    const j = await res.json();
    return j.enabled ? j.ai : null;
  }catch{ return null; }
}

export async function POST(req: NextRequest){
  const form = await req.formData();
  const file = form.get("file") as File | null;
  if(!file) return new NextResponse("missing file", { status: 400 });
  const targets = JSON.parse(String(form.get("targets")||"{}")) || {};
  const aiTopN = Number(String(form.get("aiTopN")||"0")) || 0;
  const text = await file.text();
  const lines = text.replace(/\r\n/g,'\n').replace(/\r/g,'\n').split('\n').filter(l=>l.trim().length);
  const header = lines.shift()!.split(',').map(h=>h.trim());
  const rows = lines.map(line=>{
    const cells = []; let cur=''; let inQ=false;
    for(let i=0;i<line.length;i++){
      const c=line[i];
      if(c==='"'){ if(line[i+1]==='"'){ cur+='"'; i++; } else { inQ=!inQ; } }
      else if(c===',' && !inQ){ cells.push(cur); cur=''; }
      else { cur+=c; }
    }
    cells.push(cur);
    const row:any = {}; header.forEach((h,idx)=> row[h]=cells[idx]?.trim() ?? '');
    return row;
  });

  const defaults:any = { price:250000, rent:1900, taxesAnnual:4000, insuranceAnnual:1000, vacancyPct:targets.vacancy??5, mgmtPct:targets.mgmt??8, maintenancePct:targets.maint??5, capexPct:targets.capex??5, hoaMonthly:0, ownerUtilitiesMonthly:0, closingPct:2, repairs:5000, downPct:20, ratePct:targets.rate??7.25, termYears:30, beds:3, baths:1, sqft:1100, yearBuilt:1950 };

  const out:any[] = [];
  for (const row of rows){
    const url = String(row.url||row.URL||"");
    let enriched:any = null;
    if(/^https?:\/\//i.test(url)){ enriched = await enrichFromUrl(url); }
    const addr = enriched?.address || row.address || row.Address || "";
    const inp:any = {
      address: addr,
      price: asNumber(enriched?.price ?? row.price ?? row.list_price, defaults.price),
      rent: asNumber(row.rent ?? row.estimated_rent, defaults.rent),
      taxesAnnual: asNumber(row.taxesAnnual ?? row.annual_taxes ?? row.taxes, defaults.taxesAnnual),
      insuranceAnnual: asNumber(row.insuranceAnnual ?? row.annual_insurance ?? row.insurance, defaults.insuranceAnnual),
      vacancyPct: asNumber(row.vacancyPct ?? row.vacancy, defaults.vacancyPct),
      mgmtPct: asNumber(row.mgmtPct ?? row.management, defaults.mgmtPct),
      maintenancePct: asNumber(row.maintenancePct ?? row.maintenance, defaults.maintenancePct),
      capexPct: asNumber(row.capexPct ?? row.capex, defaults.capexPct),
      hoaMonthly: asNumber(row.hoaMonthly ?? row.hoa, defaults.hoaMonthly),
      ownerUtilitiesMonthly: asNumber(row.ownerUtilitiesMonthly ?? row.owner_utilities, defaults.ownerUtilitiesMonthly),
      closingPct: asNumber(row.closingPct ?? row.closing, defaults.closingPct),
      repairs: asNumber(row.repairs ?? row.rehab_budget, defaults.repairs),
      downPct: asNumber(row.downPct ?? row.down, defaults.downPct),
      ratePct: asNumber(row.ratePct ?? row.rate, defaults.ratePct),
      termYears: asNumber(row.termYears ?? row.term, defaults.termYears),
      beds: asNumber(enriched?.beds ?? row.beds ?? row.bedrooms, defaults.beds),
      baths: asNumber(enriched?.baths ?? row.baths ?? row.bathrooms, defaults.baths),
      sqft: asNumber(enriched?.sqft ?? row.sqft ?? row.square_feet, defaults.sqft),
      yearBuilt: asNumber(enriched?.yearBuilt ?? row.yearBuilt ?? row.year_built, defaults.yearBuilt),
    };
    const stats = analyze(inp);

    const zip = extractZip(addr || String(row.zip||"")) || String(row.zip||"");
    let s8:any = null;
    if(zip){
      try{
        const hud = await fetch(`/api/hud?zip=${encodeURIComponent(zip)}&beds=${encodeURIComponent(inp.beds||3)}`);
        if(hud.ok){
          const j = await hud.json();
          s8 = j.psLow ? j : s8Fallback(inp.rent, inp.beds);
        }else{
          s8 = s8Fallback(inp.rent, inp.beds);
        }
      }catch{ s8 = s8Fallback(inp.rent, inp.beds); }
    }else{
      s8 = s8Fallback(inp.rent, inp.beds);
    }

    const picks = pickRecommended(inp, targets);
    const item:any = { ...inp, ...stats, s8Net: s8.net, s8UA: s8.ua, s8PSLow: s8.psLow, s8PSHigh: s8.psHigh, s8Source: s8.source, rec: picks.rec, offers: picks.offers, description: enriched?.description || "", images: enriched?.images || [], agent: enriched?.agent || {} };
    item._score = scoreRow(item, targets);
    out.push(item);
  }

  out.sort((a,b)=> b._score - a._score);

  if (aiTopN > 0){
    const top = out.slice(0, aiTopN);
    for (const r of top){
      r.ai = await aiSuggest({ property: r, metrics: { cfM:r.cfM, coc:r.coc, cap:r.cap, dscr:r.dscr, rec:r.rec } });
    }
  }

  const makeEmail = (r:any)=>{
    const lines = [
      `Subject: Offer on ${r.address}`,
      ``,
      `Hi ${r.agent?.name || "there"},`,
      ``,
      `I underwrote ${r.address}. Based on NOI and DSCR ${r.dscr.toFixed(2)}, here’s my recommended structure:`,
      `• ${r.rec?.structure}: $${Math.round(r.rec?.price||0).toLocaleString()} (${Math.round(r.rec?.cfM||0).toLocaleString()}/mo CF, ${Number(r.rec?.coc||0).toFixed(1)}% CoC)`,
      r.rec?.notes ? `• Terms: ${r.rec?.notes}` : ``,
      r.ai?.offerEmail?.body ? `\n---\nAI Draft:\n${r.ai.offerEmail.body}` : ``,
      ``,
      `Thanks,`,
      `[Your Name]`
    ].filter(Boolean);
    return lines.join("\n");
  };
  const emails = out.slice(0,100).map(makeEmail).join("\n\n");

  return NextResponse.json({ ranked: out, emails });
}
