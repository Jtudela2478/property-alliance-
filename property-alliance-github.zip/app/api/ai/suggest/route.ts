import { NextRequest, NextResponse } from "next/server";

const OPENAI_API_KEY = process.env.OPENAI_API_KEY!;
const MODEL = process.env.OPENAI_MODEL || "gpt-4.1-mini";

export const maxDuration = 20;

export async function POST(req: NextRequest) {
  if (!OPENAI_API_KEY) {
    return NextResponse.json({ enabled: false, reason: "No OPENAI_API_KEY set" });
  }
  const body = await req.json();
  const { property, metrics } = body;

  const resp = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${OPENAI_API_KEY}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: MODEL,
      reasoning: { effort: "medium" },
      input: [
        { role: "system", content: "You are a real-estate analyst. Be concise, conservative, investor-friendly." },
        { role: "user", content: [ { type: "text", text:
`Analyze the property and return strict JSON using this schema.
{
  "rentCheck": { "low": number, "high": number, "confidence": "low|medium|high", "notes": string },
  "condition": { "label": "Turnkey|Light Updates|Heavy Rehab|Unknown", "scope": string[] },
  "risks": string[],
  "offerEmail": { "subject": string, "body": string }
}
PROPERTY = ${JSON.stringify(property)}
METRICS = ${JSON.stringify(metrics)}` } ] }
      ],
      response_format: {
        type: "json_schema",
        json_schema: {
          name: "DealAI",
          schema: {
            type: "object",
            additionalProperties: false,
            properties: {
              rentCheck: {
                type: "object",
                properties: {
                  low: { type: "number" },
                  high: { type: "number" },
                  confidence: { type: "string", enum: ["low","medium","high"] },
                  notes: { type: "string" }
                },
                required: ["low","high","confidence","notes"]
              },
              condition: {
                type: "object",
                properties: {
                  label: { type: "string", enum: ["Turnkey","Light Updates","Heavy Rehab","Unknown"] },
                  scope: { type: "array", items: { type: "string" } }
                },
                required: ["label","scope"]
              },
              risks: { type: "array", items: { type: "string" } },
              offerEmail: {
                type: "object",
                properties: {
                  subject: { type: "string" },
                  body: { type: "string" }
                },
                required: ["subject","body"]
              }
            },
            required: ["rentCheck","condition","risks","offerEmail"]
          }
        }
      }
    })
  });

  if (!resp.ok) {
    const t = await resp.text();
    return NextResponse.json({ error: t }, { status: 500 });
  }
  const data = await resp.json();
  const first = data?.output?.[0]?.content?.[0]?.json ?? null;
  return NextResponse.json({ enabled: true, model: MODEL, ai: first });
}
