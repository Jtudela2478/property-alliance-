import { NextRequest, NextResponse } from "next/server";
import { analyze, asNumber, pickRecommended, s8Fallback } from "../../shared";
import { enrichFromUrl, extractZip } from "../_lib";

export async function POST(req: NextRequest){
  const body = await req.json();
  const { address, url, targets } = body || {};
  const defaults:any = { price:250000, rent:1900, taxesAnnual:4000, insuranceAnnual:1000, vacancyPct:targets?.vacancy??5, mgmtPct:targets?.mgmt??8, maintenancePct:targets?.maint??5, capexPct:targets?.capex??5, closingPct:2, repairs:5000, downPct:20, ratePct:targets?.rate??7.25, termYears:30, beds:3, baths:1, sqft:1100, yearBuilt:1950 };
  const enriched = url ? await enrichFromUrl(url) : null;
  const inp:any = {
    address: enriched?.address || address || "",
    price: asNumber(enriched?.price, defaults.price),
    rent: defaults.rent,
    taxesAnnual: defaults.taxesAnnual, insuranceAnnual: defaults.insuranceAnnual,
    vacancyPct: defaults.vacancyPct, mgmtPct: defaults.mgmtPct, maintenancePct: defaults.maintenancePct, capexPct: defaults.capexPct,
    closingPct: defaults.closingPct, repairs: defaults.repairs,
    downPct: defaults.downPct, ratePct: defaults.ratePct, termYears: defaults.termYears,
    beds: asNumber(enriched?.beds, defaults.beds), baths: asNumber(enriched?.baths, defaults.baths), sqft: asNumber(enriched?.sqft, defaults.sqft), yearBuilt: asNumber(enriched?.yearBuilt, defaults.yearBuilt),
  };
  const stats = analyze(inp);

  const zip = extractZip(inp.address||"");
  let s8:any = null;
  if(zip){
    try{
      const hud = await fetch(`/api/hud?zip=${encodeURIComponent(zip)}&beds=${encodeURIComponent(inp.beds||3)}`);
      if(hud.ok){
        const j = await hud.json();
        s8 = j.psLow ? j : s8Fallback(inp.rent, inp.beds);
      }else{
        s8 = s8Fallback(inp.rent, inp.beds);
      }
    }catch{ s8 = s8Fallback(inp.rent, inp.beds); }
  }else{
    s8 = s8Fallback(inp.rent, inp.beds);
  }

  const rec = pickRecommended(inp, targets || {});

  return NextResponse.json({ ...inp, ...stats, ...{ s8Net: s8.net, s8UA: s8.ua, s8PSLow: s8.psLow, s8PSHigh: s8.psHigh, s8Source: s8.source }, rec: rec.rec, offers: rec.offers, images: enriched?.images || [], description: enriched?.description || "", agent: enriched?.agent || {} });
}
