// HUD SAFMR optional token route
import { NextRequest, NextResponse } from "next/server";

export async function GET(req: NextRequest){
  const { searchParams } = new URL(req.url);
  const zip = (searchParams.get("zip")||"").slice(0,5);
  const beds = Number(searchParams.get("beds")||"3");
  const defaultUA = beds>=4?220 : beds===3?180 : beds===2?150 : 120;

  const token = process.env.HUD_API_TOKEN;
  if(!token){
    return NextResponse.json({ ua: defaultUA, source:"Heuristic (no HUD_API_TOKEN set)" });
  }
  try{
    const year = new Date().getFullYear();
    const url = `https://www.huduser.gov/hudapi/public/fmr/data?year=${year}&zip=${encodeURIComponent(zip)}&smallarea_status=1`;
    const res = await fetch(url, { headers: { "Authorization": `Bearer ${token}` } });
    if(!res.ok){
      return NextResponse.json({ ua: defaultUA, source:`HUD fallback (${res.status})` });
    }
    const data = await res.json();
    let ps: number | null = null;
    const bdKey = beds===0?"0" : String(beds);
    if (data?.data && Array.isArray(data.data) && data.data.length>0){
      const row = data.data[0];
      ps = row?.[`FMR_${bdKey}`] || row?.[`SAFMR_${bdKey}`] || row?.[`FMR${bdKey}`] || null;
      if (!ps){
        const nameMap:any = { "0":"Efficiency", "1":"One-Bedroom", "2":"Two-Bedroom", "3":"Three-Bedroom", "4":"Four-Bedroom" };
        const named = nameMap[bdKey];
        ps = row?.[named] || null;
      }
    }
    if(!ps) return NextResponse.json({ ua: defaultUA, source:"HUD (no PS found)" });
    const psLow = ps, psHigh = ps;
    const net = Math.max(0, Math.round(ps) - defaultUA);
    return NextResponse.json({ psLow, psHigh, ua: defaultUA, net, source:"HUD SAFMR" });
  }catch(e){
    return NextResponse.json({ ua: defaultUA, source:"HUD error fallback" });
  }
}
