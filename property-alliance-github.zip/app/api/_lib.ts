export function getMeta(html: string, name: string){
  const m1 = html.match(new RegExp(`<meta[^>]+property=["']${name}["'][^>]+content=["']([^"']+)["']`, 'i'));
  if (m1) return m1[1];
  const m2 = html.match(new RegExp(`<meta[^>]+name=["']${name}["'][^>]+content=["']([^"']+)["']`, 'i'));
  return m2 ? m2[1] : undefined;
}
export function getJSONLD(html: string){
  const scripts = Array.from(html.matchAll(/<script[^>]+type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi)).map(m=>m[1]);
  const out:any[] = [];
  for (const s of scripts){
    try{ const j = JSON.parse(s); out.push(j); }catch{}
  }
  return out;
}
export async function enrichFromUrl(url:string){
  try{
    const res = await fetch(url, { headers: { "User-Agent": "Mozilla/5.0 PropertyAlliance/1.0" }});
    if(!res.ok) return null;
    const html = await res.text();
    const metaTitle = getMeta(html, "og:title") || "";
    const metaDesc  = getMeta(html, "og:description") || getMeta(html, "description") || "";
    const img = getMeta(html, "og:image");
    const imgs = new Set<string>(); if (img) imgs.add(img);
    const imgMatches = Array.from(html.matchAll(/https?:\/\/[^"']+\.(?:jpg|jpeg|png|webp)/gi)).slice(0,6).map(m=>m[0]);
    imgMatches.forEach(u=>imgs.add(u));
    const jsonlds = getJSONLD(html);
    let price: number|undefined, beds:number|undefined, baths:number|undefined, sqft:number|undefined, year:number|undefined, addr:string|undefined, agent:any={};
    for (const j of jsonlds){
      const obj = Array.isArray(j) ? j[0] : j;
      price = price ?? Number(obj?.offers?.price || obj?.price || obj?.home?.price);
      beds = beds ?? Number(obj?.numberOfRooms || obj?.numberOfBedrooms || obj?.bedrooms);
      baths = baths ?? Number(obj?.numberOfBathroomsTotal || obj?.bathrooms);
      sqft = sqft ?? Number(obj?.floorSize?.value || obj?.sqft || obj?.area || obj?.size);
      year = year ?? Number(obj?.yearBuilt);
      addr = addr ?? (obj?.address?.streetAddress || obj?.address?.name);
      if(obj?.seller || obj?.agent || obj?.author){
        const ag = obj.seller || obj.agent || obj.author;
        agent.name = agent.name || ag?.name;
        agent.email = agent.email || ag?.email;
        agent.phone = agent.phone || ag?.telephone;
      }
    }
    const phone = (html.match(/\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}/)?.[0] || "").trim();
    const email = (html.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i)?.[0] || "").trim();
    agent.phone = agent.phone || phone; agent.email = agent.email || email;
    return {
      address: addr || metaTitle,
      description: metaDesc,
      images: Array.from(imgs).slice(0,6),
      price, beds, baths, sqft, yearBuilt: year,
      agent
    };
  }catch{ return null; }
}

export function extractZip(address:string){
  const m = (address||"").match(/\b\d{5}(?:-\d{4})?\b/);
  return m ? m[0].slice(0,5) : null;
}
