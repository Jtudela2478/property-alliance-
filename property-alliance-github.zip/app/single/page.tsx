"use client";
import { useState } from "react";
import { currency } from "../shared";

export default function Single(){
  const [address,setAddress]=useState("2726 Budd St, River Grove, IL 60171");
  const [url,setUrl]=useState("");
  const [targets,setTargets]=useState({ roiTarget:12, cocTarget:10, minDSCR:1.25, vacancy:5, mgmt:8, maint:5, capex:5, rate:7.25 });
  const [row,setRow]=useState<any|null>(null);
  const [ai,setAi]=useState<any|null>(null);
  const [loading,setLoading]=useState(false);

  async function runAll(){
    setLoading(true);
    try{
      const res = await fetch("/api/analyze", { method:"POST", headers:{ "Content-Type":"application/json" }, body: JSON.stringify({ address, url, targets }) });
      if(!res.ok) throw new Error(await res.text());
      const j = await res.json();
      setRow(j);
      const aiRes = await fetch("/api/ai/suggest", { method:"POST", headers:{ "Content-Type":"application/json" }, body: JSON.stringify({ property: j, metrics: { cfM:j.cfM, coc:j.coc, cap:j.cap, dscr:j.dscr, rec:j.rec } }) });
      if(aiRes.ok){
        const k = await aiRes.json();
        if(k.enabled) setAi(k.ai);
      }
    }catch(e:any){ alert(e?.message || "Run failed"); }
    finally{ setLoading(false); }
  }

  return (
    <main style={{padding:24,display:"grid",gap:16}}>
      <h1 style={{fontSize:28,fontWeight:800}}>Single Address</h1>
      <div style={{display:"grid",gap:8,border:'1px solid #334155',borderRadius:16,padding:12,background:'#0f172a'}}>
        <input placeholder="Address" value={address} onChange={e=>setAddress(e.target.value)} style={{padding:10,borderRadius:10,border:'1px solid #334155',background:'#0b1220',color:'#e5e7eb'}}/>
        <input placeholder="Listing URL (optional for photos/agent)" value={url} onChange={e=>setUrl(e.target.value)} style={{padding:10,borderRadius:10,border:'1px solid #334155',background:'#0b1220',color:'#e5e7eb'}}/>
        <button onClick={runAll} disabled={loading} style={{padding:'10px 14px',borderRadius:10,background:'#4f46e5',color:'#fff',fontWeight:700}}>{loading?'Running…':'Run (Analyze + AI)'}</button>
      </div>

      {row && (
        <div style={{display:'grid',gap:12}}>
          <div style={{border:'1px solid #334155',borderRadius:16,padding:12}}>
            <div style={{display:'grid',gridTemplateColumns:'120px 1fr',gap:12}}>
              <div style={{display:'grid',gap:6}}>
                {(row.images||[]).slice(0,1).map((src:string,idx:number)=>(<img key={idx} src={src} style={{width:120,height:90,objectFit:'cover',borderRadius:10}}/>))}
              </div>
              <div>
                <div style={{fontWeight:800}}>{row.address}</div>
                <div style={{fontSize:13,color:'#94a3b8'}}>{row.description||""}</div>
                <div style={{display:'grid',gridTemplateColumns:'repeat(6,minmax(0,1fr))',gap:8,marginTop:8,fontSize:13}}>
                  <div><b>Price</b><div>{currency(Math.round(row.price||0))}</div></div>
                  <div><b>Rent</b><div>{currency(Math.round(row.rent||0))}</div></div>
                  <div><b>CF/mo</b><div>{currency(Math.round(row.cfM||0))}</div></div>
                  <div><b>CoC</b><div>{(row.coc||0).toFixed(2)}%</div></div>
                  <div><b>ROI</b><div>{(row.cap||0).toFixed(2)}%</div></div>
                  <div><b>DSCR</b><div>{(row.dscr||0).toFixed(2)}</div></div>
                </div>
                <div style={{display:'grid',gridTemplateColumns:'repeat(3,minmax(0,1fr))',gap:8,marginTop:8,fontSize:13}}>
                  <div><b>Sec 8 Net</b><div>{currency(Math.round(row.s8Net||0))} (UA {Math.round(row.s8UA||0)})</div></div>
                  <div><b>PS</b><div>{currency(Math.round(row.s8PSLow||0))}–{currency(Math.round(row.s8PSHigh||0))} <span style={{fontSize:11,color:'#60a5fa'}}>({row.s8Source})</span></div></div>
                  <div><b>Recommended</b><div>{row.rec?.structure} @ {currency(Math.round(row.rec?.price||0))}</div></div>
                </div>
              </div>
            </div>
          </div>

          {ai && (
            <div style={{border:'1px solid #334155',borderRadius:16,padding:12,background:'#0f172a'}}>
              <div style={{fontWeight:800,marginBottom:6}}>AI Boost</div>
              <div style={{display:'grid',gridTemplateColumns:'repeat(3,minmax(0,1fr))',gap:8,fontSize:13}}>
                <div><b>Rent Band</b><div>{currency(ai.rentCheck.low)}–{currency(ai.rentCheck.high)} ({ai.rentCheck.confidence})</div><div style={{color:'#94a3b8'}}>{ai.rentCheck.notes}</div></div>
                <div><b>Condition</b><div>{ai.condition.label}</div><ul>{ai.condition.scope.map((s:string,i:number)=><li key={i}>• {s}</li>)}</ul></div>
                <div><b>Risks</b><ul>{ai.risks.map((r:string,i:number)=><li key={i}>• {r}</li>)}</ul></div>
              </div>
              <div style={{marginTop:8}}>
                <div style={{fontWeight:700}}>Offer Email Draft</div>
                <div style={{fontSize:13,whiteSpace:'pre-wrap'}}>{ai.offerEmail.body}</div>
              </div>
            </div>
          )}
        </div>
      )}
    </main>
  );
}
